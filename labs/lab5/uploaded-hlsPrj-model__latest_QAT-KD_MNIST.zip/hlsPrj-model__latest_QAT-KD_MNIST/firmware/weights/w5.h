//Numpy array shape [4, 3]
//Min -4.000000000000
//Max 4.000000000000
//Number of zeros 1

#ifndef W5_H_
#define W5_H_

#ifndef __SYNTHESIS__
weight5_t w5[12];
#else
weight5_t w5[12] = {-4, -2, 2, 2, 4, 2, -2, -2, 0, 2, 2, -2};
#endif

#endif
