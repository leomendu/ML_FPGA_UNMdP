//Numpy array shape [3, 2]
//Min -2.000000000000
//Max 2.000000000000
//Number of zeros 3

#ifndef W8_H_
#define W8_H_

#ifndef __SYNTHESIS__
weight8_t w8[6];
#else
weight8_t w8[6] = {-2, 0, 2, 0, 2, 0};
#endif

#endif
