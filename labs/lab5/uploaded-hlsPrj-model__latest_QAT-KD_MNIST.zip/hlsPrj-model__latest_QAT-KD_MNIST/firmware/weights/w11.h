//Numpy array shape [2, 10]
//Min -2.000000000000
//Max 2.000000000000
//Number of zeros 18

#ifndef W11_H_
#define W11_H_

#ifndef __SYNTHESIS__
weight11_t w11[20];
#else
weight11_t w11[20] = {0, 0, 0, 0, 0, 2, 0, -2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif

#endif
