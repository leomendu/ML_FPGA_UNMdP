//Numpy array shape [10]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 10

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
bias8_t b8[10];
#else
bias8_t b8[10] = {0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000};
#endif

#endif
