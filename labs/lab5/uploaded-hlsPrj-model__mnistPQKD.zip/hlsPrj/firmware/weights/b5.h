//Numpy array shape [7]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 7

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[7];
#else
bias5_t b5[7] = {0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000};
#endif

#endif
